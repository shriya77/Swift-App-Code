import SwiftUI

struct ContentView: View {
    @State private var hasOffset = false
    @GestureState var dragOffset = CGSize.zero // CGSize A structure that contains width and height values.
    @State var position = CGSize.zero
    
    var body: some View {
        // @State var GoodThing1: String = ""
        
        
        VStack{
            ZStack {
                
                Image("CatBody")
                    .resizable()
                    .offset(x: -20, y: 230)
                    .frame(width: 304, height: 240) // original size 304 height 240 Can use to thin and thicken the cat
                
                
                ZStack {
                    Ellipse()
                        .frame(width: 250, height: 380)
                        .offset(x: 10, y: 8)
                        .rotationEffect(.degrees(90))
                    Image("Cat mouth")
                        .offset(x: -20, y: 70)
                    Image("cat nose")
                        .offset(x: -20, y: 50)
                    
                    
                    Circle()
                        .frame(width: 60, height: 500)
                        .offset(x: -90, y: 0)
                    Circle()
                        .frame(width: 60, height: 500)
                        .offset(x: +50, y: 0)
                    Circle()
                        .fill(.white)
                        .frame(width: 25, height: 500)
                        .offset(x: +40, y: -5)
                    
                    Circle()
                        .fill(.white)
                        .frame(width: 25, height: 500)
                        .offset(x: -80, y: -5)
                }
            }
            Image("brush")
                .offset(x: position.width + dragOffset.width, y: position.height + dragOffset.height)
                .gesture(
                    DragGesture()
                        .updating($dragOffset, body: { (value, state, transaction) in
                            
                            state = value.translation
                        })
                        .onEnded({ (value) in // Remove this section and it will go back to where it starts
                            self.position.height += value.translation.height
                            self.position.width += value.translation.width
                            print("height",position.height) // So you can see coordinates
                            print("width",position.width)
                        })
                )
            
            
        }
    }
}
