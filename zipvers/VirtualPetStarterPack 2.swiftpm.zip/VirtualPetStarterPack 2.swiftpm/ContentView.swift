import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            ZStack {
                
                Image("CatBody")
                    .resizable()
                    .offset(x: -20, y: 230)
                    .frame(width: 304, height: 240)
                
                
                ZStack {
                    Image("cathead")
                    Image("Cat mouth")
                        .offset(x: -20, y: 70)
                    Image("cat nose")
                        .offset(x: -20, y: 50)
                    
                    
                    Circle()
                        .frame(width: 60, height: 500)
                        .offset(x: -90, y: 0)
                    Circle()
                        .frame(width: 60, height: 500)
                        .offset(x: +50, y: 0)
                    Circle()
                        .fill(.white)
                        .frame(width: 25, height: 500)
                        .offset(x: +40, y: -5)
                    
                    Circle()
                        .fill(.white)
                        .frame(width: 25, height: 500)
                        .offset(x: -80, y: -5)
                }
            }
        }
    }
}

// Original cat came from: https://pixabay.com/illustrations/cat-feline-little-cat-kawaii-5160456/ 
// Using under Pixabay license.
